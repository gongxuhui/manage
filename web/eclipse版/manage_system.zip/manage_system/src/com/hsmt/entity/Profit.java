package com.hsmt.entity;

/*�������ݿ��ӳ���*/
public class Profit {
	private String months;
	private int profit;

	public String getMonths() {
		return months;
	}

	public void setMonths(String months) {
		this.months = months;
	}

	public int getProfit() {
		return profit;
	}

	public void setProfit(int profit) {
		this.profit = profit;
	}

}
