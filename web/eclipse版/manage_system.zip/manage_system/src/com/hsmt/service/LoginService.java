package com.hsmt.service;

public interface LoginService {
	
	public String loginByNamePwd(String userName,String passWord);
}
