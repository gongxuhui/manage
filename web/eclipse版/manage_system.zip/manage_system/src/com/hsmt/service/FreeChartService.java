package com.hsmt.service;

import org.jfree.chart.JFreeChart;

public interface FreeChartService {
	/*���ɲ�Ʒ��ͼ��*/
	public JFreeChart getProductFreeChart();
}
